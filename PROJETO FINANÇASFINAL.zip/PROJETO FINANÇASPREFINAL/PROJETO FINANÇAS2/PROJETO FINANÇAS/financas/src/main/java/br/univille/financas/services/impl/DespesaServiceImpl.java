package br.univille.financas.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.univille.financas.entitys.Despesa;
import br.univille.financas.repository.DespesaRepository;
import br.univille.financas.services.DespesaService;

@Service
public class DespesaServiceImpl implements DespesaService {

    @Autowired
    private DespesaRepository repository;

    @Override
    public void save(Despesa despesa) {
        repository.save(despesa);
    }

    @Override
    public Despesa getReferenceById(long id) {
        return repository.getReferenceById(id);
    }

    @Override
    public List<Despesa> getAll() {
        return repository.findAll();
    }

    @Override
    public Despesa delete(long id) {
        var delDespesa = getReferenceById(id);
        repository.deleteById(id);
        return delDespesa;
    }
}
