package br.univille.financas.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;

import br.univille.financas.entitys.Usuario;
import br.univille.financas.services.UsuarioService;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;


@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/Usuario")
public class UsuarioController {
    @Autowired
    private UsuarioService service;

    @GetMapping
    public ResponseEntity<List<Usuario>> getAllUsuario(){
        var listaUsuario  = service.getAll();
        return new ResponseEntity<List<Usuario>>(listaUsuario, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Usuario> post(@RequestBody Usuario usuario){
        if(usuario.getId() == null){
            service.save(usuario);
            System.out.println(usuario);
            return new ResponseEntity<Usuario>(usuario, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> put(@PathVariable long id, @RequestBody Usuario usuario){
        var putUsuario = service.getReferenceById(id);
        if(putUsuario == null){
            return ResponseEntity.notFound().build();
        }
        
        putUsuario.setNome(usuario.getNome());
        putUsuario.setEmail(usuario.getEmail());
        putUsuario.setSenha(usuario.getSenha());
        

        service.save(putUsuario);
        return new ResponseEntity<Usuario>(putUsuario, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Usuario> delete(@PathVariable long id){
        var delUsuario = service.getReferenceById(id);
        if(delUsuario == null){
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return new ResponseEntity<Usuario>(delUsuario,HttpStatus.OK);
    }
}