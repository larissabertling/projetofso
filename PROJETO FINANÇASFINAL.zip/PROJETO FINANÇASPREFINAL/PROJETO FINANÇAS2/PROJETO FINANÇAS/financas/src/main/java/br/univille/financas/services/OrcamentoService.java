package br.univille.financas.services;

import java.util.List;

import org.springframework.stereotype.Service;

import br.univille.financas.entitys.Orcamento;


@Service
public interface OrcamentoService {
    void save(Orcamento orcamento);
    Orcamento getReferenceById(long id);
    List<Orcamento> getAll();
    Orcamento delete(long id);
}