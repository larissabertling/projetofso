package br.univille.financas.services.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import br.univille.financas.entitys.Orcamento;
import br.univille.financas.repository.OrcamentoRepository;
import br.univille.financas.services.OrcamentoService;

@Service
public class OrcamentoServiceImpl implements OrcamentoService {

    @Autowired
    private OrcamentoRepository repository;

    @Override
    public void save(Orcamento orcamento) {
        repository.save(orcamento);
    }

    @Override
    public Orcamento getReferenceById(long id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public List<Orcamento> getAll() {
        return repository.findAll();
    }

    @Override
    public Orcamento delete(long id) {
        var delorcamento = getReferenceById(id);
        repository.deleteById(id);
        return delorcamento;
    }
}
