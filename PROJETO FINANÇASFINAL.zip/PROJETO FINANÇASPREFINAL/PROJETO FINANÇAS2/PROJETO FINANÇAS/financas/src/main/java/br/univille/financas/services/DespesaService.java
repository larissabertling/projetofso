package br.univille.financas.services;

import java.util.List;

import org.springframework.stereotype.Service;

import br.univille.financas.entitys.Despesa;

@Service
public interface DespesaService {
    void save(Despesa conta);
    Despesa getReferenceById(long id);
    List<Despesa> getAll();
    Despesa delete(long id);
}