package br.univille.financas.services;

import java.util.List;

import org.springframework.stereotype.Service;

import br.univille.financas.entitys.Usuario;


@Service
public interface UsuarioService {
    void save(Usuario usuario);
    Usuario getReferenceById(long id);
    List<Usuario> getAll();
    Usuario delete(long id);
}