package br.univille.financas.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.univille.financas.entitys.Conta;
import br.univille.financas.repository.ContaRepository;
import br.univille.financas.services.ContaService;


@Service
public class ContaServiceImpl implements ContaService {

    @Autowired
    private ContaRepository repository;

    @Override
    public void save(Conta conta) {
        repository.save(conta);
    }

    @Override
    public Conta getReferenceById(long id) {
        return repository.getReferenceById(id);
    }

    @Override
    public List<Conta> getAll() {
        return repository.findAll();
    }

    @Override
    public Conta delete(long id) {
        var delconta = getReferenceById(id);
        repository.deleteById(id);
        return delconta;
    }

}
