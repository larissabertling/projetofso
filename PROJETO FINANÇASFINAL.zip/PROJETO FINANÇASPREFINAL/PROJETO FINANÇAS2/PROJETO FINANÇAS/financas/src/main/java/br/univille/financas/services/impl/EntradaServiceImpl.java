package br.univille.financas.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.univille.financas.entitys.Entrada;
import br.univille.financas.repository.EntradaRepository;
import br.univille.financas.services.EntradaService;

@Service
public class EntradaServiceImpl implements EntradaService {

    @Autowired
    private EntradaRepository repository;

    @Override
    public void save(Entrada entrada) {
        repository.save(entrada);
    }

    @Override
    public Entrada getReferenceById(long id) {
        return repository.getReferenceById(id);
    }

    @Override
    public List<Entrada> getAll() {
        return repository.findAll();
    }

    @Override
    public Entrada delete(long id) {
        var delEntrada = getReferenceById(id);
        repository.deleteById(id);
        return delEntrada;
    }
}
