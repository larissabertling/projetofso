package br.univille.financas.services;

import java.util.List;

import org.springframework.stereotype.Service;

import br.univille.financas.entitys.Conta;

@Service
public interface ContaService {
    void save(Conta conta);
    Conta getReferenceById(long id);
    List<Conta> getAll();
    Conta delete(long id);
}