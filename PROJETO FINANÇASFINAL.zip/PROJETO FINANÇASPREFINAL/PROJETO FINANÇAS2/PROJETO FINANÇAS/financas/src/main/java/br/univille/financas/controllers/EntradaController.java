package br.univille.financas.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;

import br.univille.financas.entitys.Entrada;
import br.univille.financas.services.EntradaService;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/entradas")
public class EntradaController {
    @Autowired
    private EntradaService service;

    @GetMapping
    public ResponseEntity<List<Entrada>> getAllEntradas(){
        var listaEntradas = service.getAll();
        return new ResponseEntity<List<Entrada>>(listaEntradas, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Entrada> post(@RequestBody Entrada entrada){
        if(entrada.getId() == null){
            service.save(entrada);
            return new ResponseEntity<Entrada>(entrada, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Entrada> put(@PathVariable long id, @RequestBody Entrada entrada){
        var putEntrada = service.getReferenceById(id);
        if(putEntrada == null){
            return ResponseEntity.notFound().build();
        }

        putEntrada.setData(entrada.getData());
        putEntrada.setValor(entrada.getValor());
        putEntrada.setDescricao(entrada.getDescricao());
        putEntrada.setConta(entrada.getConta());

        service.save(putEntrada);
        return new ResponseEntity<Entrada>(putEntrada, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Entrada> delete(@PathVariable long id){
        var delEntrada = service.getReferenceById(id);
        if(delEntrada == null){
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return new ResponseEntity<Entrada>(delEntrada, HttpStatus.OK);
    }
}
