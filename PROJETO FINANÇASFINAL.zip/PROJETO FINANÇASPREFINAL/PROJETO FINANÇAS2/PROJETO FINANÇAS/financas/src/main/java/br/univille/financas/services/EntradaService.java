package br.univille.financas.services;

import java.util.List;

import org.springframework.stereotype.Service;

import br.univille.financas.entitys.Entrada;

@Service
public interface EntradaService {
    void save(Entrada conta);
    Entrada getReferenceById(long id);
    List<Entrada> getAll();
    Entrada delete(long id);
}