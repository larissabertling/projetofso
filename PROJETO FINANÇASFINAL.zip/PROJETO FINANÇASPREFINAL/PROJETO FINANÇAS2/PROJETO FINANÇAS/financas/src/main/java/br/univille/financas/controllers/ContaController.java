package br.univille.financas.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;

import br.univille.financas.entitys.Conta;
import br.univille.financas.services.ContaService;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;


@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/Conta")
public class ContaController {
    @Autowired
    private ContaService service;

    @GetMapping
    public ResponseEntity<List<Conta>> getAllConta(){
        var listaConta  = service.getAll();
        return new ResponseEntity<List<Conta>>(listaConta, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Conta> post(@RequestBody Conta conta){
        if(conta.getId() == 0){
            service.save(conta);
            System.out.println(conta);
            return new ResponseEntity<Conta>(conta, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Conta> put(@PathVariable long id, @RequestBody Conta conta){
        var putConta = service.getReferenceById(id);
        if(putConta == null){
            return ResponseEntity.notFound().build();
        }
        
        putConta.setInstituicaoFinanceira(conta.getInstituicaoFinanceira());
        putConta.setNome(conta.getNome());
        putConta.setAgencia(conta.getAgencia());
        putConta.setNumeroConta(conta.getNumeroConta());
        putConta.setTipo(conta.getTipo());
        putConta.setSaldo(conta.getSaldo());
        
        service.save(putConta);
        return new ResponseEntity<Conta>(putConta, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Conta> delete(@PathVariable long id){
        var delConta = service.getReferenceById(id);
        if(delConta == null){
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return new ResponseEntity<Conta>(delConta,HttpStatus.OK);
    }
}