package br.univille.financas.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;

import br.univille.financas.entitys.Despesa;
import br.univille.financas.services.DespesaService;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/despesas")
public class DespesaController {
    @Autowired
    private DespesaService service;

    @GetMapping
    public ResponseEntity<List<Despesa>> getAllDespesas(){
        var listaDespesas = service.getAll();
        return new ResponseEntity<List<Despesa>>(listaDespesas, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Despesa> post(@RequestBody Despesa despesa){
        if(despesa.getId() == null){
            service.save(despesa);
            return new ResponseEntity<Despesa>(despesa, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Despesa> put(@PathVariable long id, @RequestBody Despesa despesa){
        var putDespesa = service.getReferenceById(id);
        if(putDespesa == null){
            return ResponseEntity.notFound().build();
        }

        putDespesa.setData(despesa.getData());
        putDespesa.setValor(despesa.getValor());
        putDespesa.setDescricao(despesa.getDescricao());
        putDespesa.setConta(despesa.getConta());

        service.save(putDespesa);
        return new ResponseEntity<Despesa>(putDespesa, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Despesa> delete(@PathVariable long id){
        var delDespesa = service.getReferenceById(id);
        if(delDespesa == null){
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return new ResponseEntity<Despesa>(delDespesa, HttpStatus.OK);
    }
}
