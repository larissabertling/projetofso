package br.univille.financas.controllers;

import java.util.List;
import org.springframework.web.bind.annotation.RestController;
import br.univille.financas.entitys.Orcamento;
import br.univille.financas.services.OrcamentoService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/Orcamento")
public class OrcamentoController {
    @Autowired
    private OrcamentoService service;

    @GetMapping
    public ResponseEntity<List<Orcamento>> getAllOrcamento(){
        var listaOrcamento  = service.getAll();
        return new ResponseEntity<List<Orcamento>>(listaOrcamento, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Orcamento> getOrcamentoById(@PathVariable long id) {
        var orcamento = service.getReferenceById(id);
        if (orcamento == null) {
            return ResponseEntity.notFound().build();
        }
        return new ResponseEntity<Orcamento>(orcamento, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Orcamento> post(@RequestBody Orcamento orcamento){
        if(orcamento.getId() == null){
            service.save(orcamento);
            System.out.println(orcamento);
            return new ResponseEntity<Orcamento>(orcamento, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Orcamento> put(@PathVariable long id, @RequestBody Orcamento orcamento){
        var putOrcamento = service.getReferenceById(id);
        if(putOrcamento == null){
            return ResponseEntity.notFound().build();
        }

        putOrcamento.setMes(orcamento.getMes());
        putOrcamento.setAno(orcamento.getAno());
        putOrcamento.setCategoria(orcamento.getCategoria());
        putOrcamento.setValorTotal(orcamento.getValorTotal());
        putOrcamento.setUsuario(orcamento.getUsuario());
        
        service.save(putOrcamento);
        return new ResponseEntity<Orcamento>(putOrcamento, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Orcamento> delete(@PathVariable long id){
        var delOrcamento = service.getReferenceById(id);
        if(delOrcamento == null){
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return new ResponseEntity<Orcamento>(delOrcamento,HttpStatus.OK);
    }
}
