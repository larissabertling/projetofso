package br.univille.projectapi2024.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.univille.projectapi2024.entity.Ganho;


@Repository
public interface GanhoRepository extends JpaRepository<Ganho,Long>{}