package br.univille.projectapi2024.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import br.univille.projectapi2024.entity.Gasto;


@Repository
public interface GastoRepository extends JpaRepository<Gasto,Long>{}