package br.univille.projectapi2024.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class Gasto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column
    private long valor;

    @Column(length = 1000,nullable = false)
    private String descricao;

    @Column(length = 15)
    private String categoriaGasto;

    @Temporal(TemporalType.DATE)
    private Date dataGasto;

    public Date getDataGasto() {
        return dataGasto;
    }
    public void setDataGasto(Date dataGasto) {
        this.dataGasto = dataGasto;
    }
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getDescricao() {
        return descricao;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public String getCategoriaGasto() {
        return categoriaGasto;
    }
    public void setCategoriaGasto(String categoriaGasto) {
        this.categoriaGasto = categoriaGasto;
    }

    public long getValor() {
        return valor;
    }
    public void setValor(long valor) {
        this.valor = valor;
    }

}