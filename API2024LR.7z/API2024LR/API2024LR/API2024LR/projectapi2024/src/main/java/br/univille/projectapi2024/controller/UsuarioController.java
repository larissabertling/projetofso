package br.univille.projectapi2024.controller;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;

import br.univille.projectapi2024.entity.Usuario;
import br.univille.projectapi2024.service.UsuarioService;

@RestController
@RequestMapping("/api/v1/usuario")
public class UsuarioController {
    @Autowired
    private UsuarioService service;

    @GetMapping
    public ResponseEntity<List<Usuario>> getAllUsers(){
        var listaUsers  = service.getAll();
        return new ResponseEntity<List<Usuario>>(listaUsers, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Usuario> post(@RequestBody Usuario user){
        if(user.getId() == 0){
            service.save(user);
            System.out.println(user);
            return new ResponseEntity<Usuario>(user, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> put(@PathVariable long id, @RequestBody Usuario user){
        var putuser = service.getById(id);
        if(putuser == null){
            return ResponseEntity.notFound().build();
        }

        putuser.setNome(user.getNome());
        putuser.setLogin(user.getLogin());
        putuser.setSenha(user.getSenha());
        putuser.setDataNascimento(user.getDataNascimento());

        service.save(putuser);
        return new ResponseEntity<Usuario>(putuser, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Usuario> delete(@PathVariable long id){
        var deluser = service.getById(id);
        if(deluser == null){
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return new ResponseEntity<Usuario>(deluser,HttpStatus.OK);
    }
}
