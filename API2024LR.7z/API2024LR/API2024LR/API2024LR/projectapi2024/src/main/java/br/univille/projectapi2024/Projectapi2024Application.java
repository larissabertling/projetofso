package br.univille.projectapi2024;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projectapi2024Application {

	public static void main(String[] args) {
		SpringApplication.run(Projectapi2024Application.class, args);
	}

}
