package br.univille.projectapi2024.service;

    import java.util.List;
    
    import org.springframework.stereotype.Service;

import br.univille.projectapi2024.entity.Ganho;
    
    @Service
    public interface GanhoService {
        void save(Ganho ganho);
        Ganho getById(long id);
        List<Ganho> getAll();
        Ganho delete(long id);
    }

