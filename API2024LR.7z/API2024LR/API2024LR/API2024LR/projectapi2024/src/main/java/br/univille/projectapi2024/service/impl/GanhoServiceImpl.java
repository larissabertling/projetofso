package br.univille.projectapi2024.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.univille.projectapi2024.entity.Ganho;
import br.univille.projectapi2024.repository.GanhoRepository;
import br.univille.projectapi2024.service.GanhoService;

@Service
public class GanhoServiceImpl implements GanhoService {
    
    @Autowired
    private GanhoRepository repository;

    @Override
    public void save(Ganho ganho) {
        repository.save(ganho);
    }

    @Override
    public Ganho getById(long id) {
        return repository.getById(id);
    }

    @Override
    public List<Ganho> getAll() {
        return repository.findAll();
    }

    @Override
    public Ganho delete(long id) {
        var delganho = getById(id);
        repository.deleteById(id);
        return delganho;
    }
    
}