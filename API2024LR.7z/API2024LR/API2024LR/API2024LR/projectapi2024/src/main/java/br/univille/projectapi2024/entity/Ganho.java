package br.univille.projectapi2024.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})

public class Ganho {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column
    private long valor;

    @Column(length = 1000,nullable = false)
    private String descricao;

    @Column(length = 15)
    private String categoriaGanho;

    @Temporal(TemporalType.DATE)
    private Date dataGanho;

    public Date getDataGanho() {
        return dataGanho;
    }
    public void setDataGanho(Date dataGanho) {
        this.dataGanho = dataGanho;
    }
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getDescricao() {
        return descricao;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public String getCategoriaGanho() {
        return categoriaGanho;
    }
    public void setCategoriaGanho(String categoriaGanho) {
        this.categoriaGanho = categoriaGanho;
    }

    public long getValor() {
        return valor;
    }
    public void setValor(long valor) {
        this.valor = valor;
    }

}