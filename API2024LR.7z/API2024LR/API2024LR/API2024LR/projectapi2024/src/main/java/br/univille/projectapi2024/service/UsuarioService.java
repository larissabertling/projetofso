package br.univille.projectapi2024.service;

import java.util.List;

import org.springframework.stereotype.Service;
import br.univille.projectapi2024.entity.Usuario;


@Service
public interface UsuarioService {
    void save(Usuario user);
    Usuario getById(long id);
    List<Usuario> getAll();
    Usuario delete(long id);
}