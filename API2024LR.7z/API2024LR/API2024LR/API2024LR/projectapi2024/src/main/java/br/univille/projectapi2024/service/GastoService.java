package br.univille.projectapi2024.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.univille.projectapi2024.entity.Gasto;


@Service
public interface GastoService {
    void save(Gasto gasto);
    Gasto getById(long id);
    List<Gasto> getAll();
    Gasto delete(long id);
}