package br.univille.projectapi2024.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.univille.projectapi2024.entity.Usuario;
import br.univille.projectapi2024.repository.UsuarioRepository;
import br.univille.projectapi2024.service.UsuarioService;

@Service
public class UsuarioServiceImpl implements UsuarioService {
    
    @Autowired
    private UsuarioRepository repository;

    @Override
    public void save(Usuario user) {
        repository.save(user);
    }

    @Override
    public Usuario getById(long id) {
        return repository.getById(id);
    }

    @Override
    public List<Usuario> getAll() {
        return repository.findAll();
    }

    @Override
    public Usuario delete(long id) {
        var deluser = getById(id);
        repository.deleteById(id);
        return deluser;
    }
    
}