package br.univille.projectapi2024.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.univille.projectapi2024.entity.Gasto;
import br.univille.projectapi2024.repository.GastoRepository;
import br.univille.projectapi2024.service.GastoService;

@Service
public class GastoServiceImpl implements GastoService {
    
    @Autowired
    private GastoRepository repository;

    @Override
    public void save(Gasto gasto) {
        repository.save(gasto);
    }

    @Override
    public Gasto getById(long id) {
        return repository.getById(id);
    }

    @Override
    public List<Gasto> getAll() {
        return repository.findAll();
    }

    @Override
    public Gasto delete(long id) {
        var delgasto = getById(id);
        repository.deleteById(id);
        return delgasto;
    }
    
}