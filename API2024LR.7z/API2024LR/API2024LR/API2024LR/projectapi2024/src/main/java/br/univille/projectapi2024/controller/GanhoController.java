package br.univille.projectapi2024.controller;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;

import br.univille.projectapi2024.entity.Ganho;
import br.univille.projectapi2024.service.GanhoService;

@RestController
@RequestMapping("/api/v1/ganho")
public class GanhoController {
    @Autowired
    private GanhoService service;

    @GetMapping
    public ResponseEntity<List<Ganho>> getAllGanho(){
        var listaGanho  = service.getAll();
        return new ResponseEntity<List<Ganho>>(listaGanho, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Ganho> post(@RequestBody Ganho ganho){
        if(ganho.getId() == 0){
            service.save(ganho);
            System.out.println(ganho);
            return new ResponseEntity<Ganho>(ganho, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Ganho> put(@PathVariable long id, @RequestBody Ganho ganho){
        var putGanho = service.getById(id);
        if(putGanho == null){
            return ResponseEntity.notFound().build();
        }

        putGanho.setValor(ganho.getValor());
        putGanho.setDescricao(ganho.getDescricao());
        putGanho.setCategoriaGanho(ganho.getCategoriaGanho());
        putGanho.setDataGanho(ganho.getDataGanho());
        

        service.save(putGanho);
        return new ResponseEntity<Ganho>(putGanho, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Ganho> delete(@PathVariable long id){
        var delGanho = service.getById(id);
        if(delGanho == null){
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return new ResponseEntity<Ganho>(delGanho,HttpStatus.OK);
    }
}

/*
Categorias:
Salário Fixo
Freelance
Renda variável
*/
