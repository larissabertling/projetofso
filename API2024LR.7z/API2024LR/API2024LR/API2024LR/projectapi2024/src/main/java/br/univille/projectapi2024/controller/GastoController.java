package br.univille.projectapi2024.controller;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;

import br.univille.projectapi2024.entity.Gasto;
import br.univille.projectapi2024.service.GastoService;

@RestController
@RequestMapping("/api/v1/gasto")
public class GastoController {
    @Autowired
    private GastoService service;

    @GetMapping
    public ResponseEntity<List<Gasto>> getAllGasto(){
        var listaGasto  = service.getAll();
        return new ResponseEntity<List<Gasto>>(listaGasto, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Gasto> post(@RequestBody Gasto gasto){
        if(gasto.getId() == 0){
            service.save(gasto);
            System.out.println(gasto);
            return new ResponseEntity<Gasto>(gasto, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Gasto> put(@PathVariable long id, @RequestBody Gasto gasto){
        var putGasto = service.getById(id);
        if(putGasto == null){
            return ResponseEntity.notFound().build();
        }

        putGasto.setValor(gasto.getValor());
        putGasto.setDescricao(gasto.getDescricao());
        putGasto.setCategoriaGasto(gasto.getCategoriaGasto());
        putGasto.setDataGasto(gasto.getDataGasto());
        

        service.save(putGasto);
        return new ResponseEntity<Gasto>(putGasto, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Gasto> delete(@PathVariable long id){
        var delGasto = service.getById(id);
        if(delGasto == null){
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return new ResponseEntity<Gasto>(delGasto,HttpStatus.OK);
    }
}

/*
Categorias:
Moradia
Alimentação
Transporte
Saúde
Educação
Lazer
Vestuário
*/
