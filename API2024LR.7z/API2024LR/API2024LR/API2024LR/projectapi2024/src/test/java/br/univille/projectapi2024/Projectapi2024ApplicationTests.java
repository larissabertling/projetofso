package br.univille.projectapi2024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projectapi2024ApplicationTests {

	@Test
	void contextLoads() {
	}

}
